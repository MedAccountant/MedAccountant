import requests

class Testauth:
    def test_auth(self):
        response = requests.post("http://77.232.130.90:8081/auth_check", headers={"Authorization": "Bearer eyJhbGciOiJIUzI1NiJ9.eyJkZXBhcnRtZW50cyI6W10sInJvbGUiOiJBZG1pbiIsInN1YiI6IkFkbSIsImlhdCI6MTcwMzc2MzE4NiwiZXhwIjoxNzAzODQ5NTg2fQ.l9ZmTArRMo1DDsdmu8uYCtqDHi4KiA1sicYcaCLo_MA"})
        assert response.status_code == 405
        print(response.text)



