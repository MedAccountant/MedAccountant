import requests

class TestLoginProtection:
    def test_pass_protection(self):
        body = {"login": "Adm", "password": "4321"}
        response = requests.post("http://77.232.130.90:8081/auth", json=body)
        assert response.status_code == 401
        print(response.text)
    def test_log_protection(self):
        body = {"login": "Adm2", "password": "1234"}
        response = requests.post("http://77.232.130.90:8081/auth", json=body)
        assert response.status_code == 401
        print(response.text)