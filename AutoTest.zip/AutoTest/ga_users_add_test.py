import requests

class TestUserAdd:
    def test_user_add(self):
        body = {"login": "Testlog", "nickname": "Testlog", "role": "Admin", "password": "12345", "departments":[{"departmentName": "Dep2", "workingMarker": "true"}]}
        response = requests.post("http://77.232.130.90:8081/Vista/admin/users", headers={"Authorization": "Bearer eyJhbGciOiJIUzI1NiJ9.eyJkZXBhcnRtZW50cyI6W10sInJvbGUiOiJBZG1pbiIsInN1YiI6IkFkbSIsImlhdCI6MTcwMzc2MzE4NiwiZXhwIjoxNzAzODQ5NTg2fQ.l9ZmTArRMo1DDsdmu8uYCtqDHi4KiA1sicYcaCLo_MA"} , json=body)
        assert response.status_code == 200
        print(response.text)