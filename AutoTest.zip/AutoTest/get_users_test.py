import requests

def test_get_users():
    #body = {"login": "Adm2", "password": "1234"}
    response = requests.get("http://77.232.130.90:8081/Vista/admin/users", headers={"Authorization": "Bearer eyJhbGciOiJIUzI1NiJ9.eyJkZXBhcnRtZW50cyI6W10sInJvbGUiOiJBZG1pbiIsInN1YiI6IkFkbSIsImlhdCI6MTcwMzc2MzE4NiwiZXhwIjoxNzAzODQ5NTg2fQ.l9ZmTArRMo1DDsdmu8uYCtqDHi4KiA1sicYcaCLo_MA"})
    assert response.status_code == 200
    print(response.text)