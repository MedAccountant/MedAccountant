import requests
import random

class TestSupplyAdd:
    def test_supply_add(self):
        sets = ['qwe', 'zxc', 'asd', 'gtv', 'gvz', 'rps', 'prw', 'bxz', 'rpt', 'mbf', 'qwez', 'bf']
        n_login = random.choice(sets)
        body = {"email": "testmail@mail.ru", "nickname": n_login, "role": "Admin", "departments":[{"departmentName": "Dep2", "workingMarker": "true"}], "workingMarker":"true"}
        response = requests.post("http://77.232.130.90:8081/Vista/admin/suppliers", headers={"Authorization": "Bearer eyJhbGciOiJIUzI1NiJ9.eyJkZXBhcnRtZW50cyI6W10sInJvbGUiOiJBZG1pbiIsInN1YiI6IkFkbSIsImlhdCI6MTcwMzc2MzE4NiwiZXhwIjoxNzAzODQ5NTg2fQ.l9ZmTArRMo1DDsdmu8uYCtqDHi4KiA1sicYcaCLo_MA"}, json=body)
        assert response.status_code == 200
        print(response.text)