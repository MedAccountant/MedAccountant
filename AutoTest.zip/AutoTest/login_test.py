import requests

class TestLogin:
    def test_login(self):
        body = {"login": "Adm", "password": "1234"}
        response = requests.post("http://77.232.130.90:8081/auth", json=body)
        assert response.status_code == 200
        print(response.text)
