//
//  Random_Forest.swift
//  Stocks_More_Suffer
//
//  Created by Alex Glukhov on 02.12.2023.
//

import Foundation
struct Tree : Codable{
    private enum Coding_Keys : String, CodingKey{
        case Valid
        case Hash
        case Value
        case Data_Type
        case Children
        case Res_Type
        case Res
        case Res_Probs
    }
    public func encode(to encoder: Encoder) throws {
        var cont = encoder.container(keyedBy: Coding_Keys.self)
        try cont.encode(Valid, forKey: .Valid)
        try cont.encode(Hash, forKey: .Hash)
        try cont.encode(Data_Type, forKey: .Data_Type)
        try cont.encode(Children, forKey: .Children)
        try cont.encode(Res_Type, forKey: .Res_Type)
        try cont.encode(Res_Probs, forKey: .Res_Probs)
        switch Data_Type{
        case "Int":
            try cont.encode(Value as! [Int], forKey: .Value)
        case "Double":
            try cont.encode(Value as! [Double], forKey: .Value)
        case "Bool":
            try cont.encode(Value as! [Bool], forKey: .Value)
        default:
            try cont.encode(Value as! [String], forKey: .Value)
        }
        switch Res_Type{
        case "Int":
            try cont.encode(Res as! [Int], forKey: .Res)
        case "Double":
            try cont.encode(Res as! [Double], forKey: .Res)
        case "Bool":
            try cont.encode(Res as! [Bool], forKey: .Res)
        default:
            try cont.encode(Res as! [String], forKey: .Res)
        }
    }
    public init(from decoder: Decoder) throws {
        let cont = try decoder.container(keyedBy: Coding_Keys.self)
        Valid = try cont.decode(Bool.self, forKey: .Valid)
        Hash = try cont.decode(Int.self, forKey: .Hash)
        Data_Type = try cont.decode(String.self, forKey: .Data_Type)
        Res_Type = try cont.decode(String.self, forKey: .Res_Type)
        Res_Probs = try cont.decode([Double].self, forKey: .Res_Probs)
        Children = try cont.decode([Tree].self, forKey: .Children)
        Value = []
        Res = []
        switch Data_Type{
        case "Int":
            Value = try cont.decode([Int].self, forKey: .Value)
        case "Double":
            Value = try cont.decode([Double].self, forKey: .Value)
        case "Bool":
            Value = try cont.decode([Bool].self, forKey: .Value)
        default:
            Value = try cont.decode([String].self, forKey: .Value)
        }
        switch Res_Type{
        case "Int":
            Res = try cont.decode([Int].self, forKey: .Res)
        case "Double":
            Res = try cont.decode([Double].self, forKey: .Res)
        case "Bool":
            Res = try cont.decode([Bool].self, forKey: .Res)
        default:
            Res = try cont.decode([String].self, forKey: .Res)
        }
    }
    var Valid : Bool
    var Hash : Int
    var Value : [Any]
    var Data_Type : String
    var Children : [Tree]?
    var Res_Type : String
    var Res : [Any]
    var Res_Probs : [Double]
    init(Input_Array: [[Any]]? = nil, Key_Creteria: Int? = nil, Defined_Keys: [Int]? = nil, Added_Criteries: [Int]? = nil, Branching_Limit: Int? = nil){
        self.Valid = false
        self.Hash = -1
        self.Value = []
        self.Data_Type = "nil"
        self.Children = nil
        self.Res = []
        self.Res_Probs = []
        self.Res_Type = "nil"
    }
    func Get_Res_Fast(Entry: [Any])->[[Any]?]{
        if self.Hash < Entry.count{
            if self.Data_Type == "String" || self.Data_Type == "Bool"{
                if let Pos = Value.firstIndex(where: {equals(x: $0, y: Entry[self.Hash])}){
                    if self.Hash != -1 && self.Children != nil && self.Children!.count > Pos && self.Children![Pos].Valid{
                        return self.Children![Pos].Get_Res_Fast(Entry: Entry)
                    }
                    else{
                        if equals(x: Res, y: []) && self.Res_Probs == []{
                            return [[self.Res_Type], nil, nil]
                        }
                        else if equals(x: Res, y: []){
                            return [[self.Res_Type], nil, self.Res_Probs]
                        }
                        else if self.Res_Probs == []{
                            return [[self.Res_Type], self.Res, nil]
                        }
                        else{
                            return [[self.Res_Type], self.Res, self.Res_Probs]
                        }
                    }
                }
                else{
                    if equals(x: Res, y: []) && self.Res_Probs == []{
                        return [[self.Res_Type], nil, nil]
                    }
                    else if equals(x: Res, y: []){
                        return [[self.Res_Type], nil, self.Res_Probs]
                    }
                    else if self.Res_Probs == []{
                        return [[self.Res_Type], self.Res, nil]
                    }
                    else{
                        return [[self.Res_Type], self.Res, self.Res_Probs]
                    }
                }
            }
            else{
                for i in 0..<self.Value.count{
                    if self.Data_Type == "Int" && Value[i] as! Double >= Double(Entry[self.Hash] as? Int ?? Int.max) || self.Data_Type == "Int" && Value[i] as! Double >= Entry[self.Hash] as? Double ?? Double.greatestFiniteMagnitude || Value[i] as! Double >= Entry[self.Hash] as? Double ?? Double.greatestFiniteMagnitude || Value[i] as! Double >= Double(Entry[self.Hash] as? Int ?? Int.max){
                        if self.Hash != -1 && self.Children != nil && self.Children!.count > i && self.Children![i].Valid{
                            return self.Children![i].Get_Res_Fast(Entry: Entry)
                        }
                        else{
                            if equals(x: Res, y: []) && self.Res_Probs == []{
                                return [[self.Res_Type], nil, nil]
                            }
                            else if equals(x: Res, y: []){
                                return [[self.Res_Type], nil, self.Res_Probs]
                            }
                            else if self.Res_Probs == []{
                                return [[self.Res_Type], self.Res, nil]
                            }
                            else{
                                return [[self.Res_Type], self.Res, self.Res_Probs]
                            }
                        }
                    }
                }
                if self.Hash != -1 && self.Children != nil && self.Children!.count == self.Value.count && self.Children![self.Value.count - 1].Valid{
                    return self.Children![self.Value.count - 1].Get_Res_Fast(Entry: Entry)
                }
                else{
                    if equals(x: Res, y: []) && self.Res_Probs == []{
                        return [[self.Res_Type], nil, nil]
                    }
                    else if equals(x: Res, y: []){
                        return [[self.Res_Type], nil, self.Res_Probs]
                    }
                    else if self.Res_Probs == []{
                        return [[self.Res_Type], self.Res, nil]
                    }
                    else{
                        return [[self.Res_Type], self.Res, self.Res_Probs]
                    }
                }
            }
        }
        else{
            print("Dimensions of Train set and Given Example are different, Full Res Part")
            return [nil, nil, nil]
        }
    }
}
class Random_Forest : Codable{
    private var Working : Bool
    private var Best_Forest : [Tree] = []
    private var Classifier : Bool
    public init(f_Name: String){
        let Dec = JSONDecoder()
        let Url = URL(fileURLWithPath: f_Name)
        guard let data = try? Data.init(contentsOf: Url) else{
            print("Error During Reading Process(Random Forest)")
            self.Working = false
            self.Classifier = true
            return
        }
        guard let Decd = try? Dec.decode(Random_Forest.self, from: data) else{
            print("Error During Decoding Process(Random Forest)")
            self.Working = false
            self.Classifier = true
            return
        }
        self.Best_Forest = Decd.Best_Forest
        self.Working = Decd.Working
        self.Classifier = Decd.Classifier
    }
    public func Save_Model(f_Name: String){
        let Enc = JSONEncoder()
        guard let Encd = try? Enc.encode(self) else{
            print("Error During Encoding Process(Random Forest)")
            return
        }
        let Url = URL(fileURLWithPath: f_Name)
        do{
            try Encd.write(to: Url)
        }
        catch{
            print("Error During Writing Process(Random Forest)")
        }
    }
    init(Is_It_Classifier: Bool = true){
        self.Working = false
        self.Classifier = Is_It_Classifier
    }
    public func Get_Predict_Short(Input: [Any], Unique_Forest: [Tree] = [])->Any{
        let Ans_Unique = Get_Trees_Answers(Input: Input, Forest: Unique_Forest.isEmpty ? self.Best_Forest : Unique_Forest)
        if self.Classifier{
            let Ans_Counts = Ans_Unique[1] as! [Double]
            return Ans_Unique[0][Ans_Counts.firstIndex(of: Ans_Counts.max()!)!]
        }
        else{
            var Res : Double = Double.zero
            let Ans_Probs = Ans_Unique[1] as! [Double]
            for i in 0..<Ans_Unique[0].count{
                let buf = String(describing: Ans_Unique[0][i])
                Res += Double(buf)! * Ans_Probs[i]
            }
            return Res / Double(Ans_Probs.count)
        }
    }
    private func Get_Trees_Answers(Input: [Any], Forest : [Tree])->[[Any]]{
        var Res_Names : [Any] = []
        var Res : [Double] = []
        for Tr in Forest{
            let Buf_Res = Tr.Get_Res_Fast(Entry: Input)
            if Buf_Res.firstIndex(where: {$0 == nil}) == nil{
                if Classifier{
                    let Buf_Probs = Buf_Res[2]! as! [Double]
                    let Max_Prob = Buf_Probs.firstIndex(of: Buf_Probs.max()!)!
                    Res_Names += [Buf_Res[1]![Max_Prob]]
                    Res += [Buf_Probs[Max_Prob]]
                }
                else{
                    Res_Names += Buf_Res[1]!
                    Res += Buf_Res[2]! as! [Double]
                }
                
            }
        }
        return Count_Uniques(Names: Res_Names, Probs: Res)
    }
    private func Count_Uniques(Names: [Any], Probs: [Double])->[[Any]]{
        var Unique_Names : [Any] = []
        var Counts : [Double] = []
        var Counter_Each : [Double] = []
        for i in 0..<Names.count{
            if let Idx = Unique_Names.firstIndex(where: {equals(x: $0, y: Names[i])}){
                Counts[Idx] += Probs[i]
                Counter_Each[Idx] += 1.0
            }
            else{
                Unique_Names += [Names[i]]
                Counts.append(Probs[i])
                Counter_Each.append(1.0)
            }
        }
        if self.Classifier{
            return [Unique_Names, Counter_Each]
        }
        else{
            for i in 0..<Counts.count{
                Counts[i] /= Counter_Each[i]
            }
            return [Unique_Names, Counts]
        }
    }
}
