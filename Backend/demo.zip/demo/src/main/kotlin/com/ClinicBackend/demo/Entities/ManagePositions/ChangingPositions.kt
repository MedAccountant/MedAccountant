package com.ClinicBackend.demo.Entities.ManagePositions

import com.ClinicBackend.demo.Entities.ManagePositions.CurrentPosition
import jakarta.persistence.*

@Entity
@Table(name="changing_positions")
open class ChangingPositions() {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "changing_positions_id")
    open var changingPositionsId:Long?=null

    @OneToOne
    @JoinColumn(name="old_current_position", nullable = false)
    open var oldCurrentPosition:CurrentPosition?=null

    @OneToOne
    @JoinColumn(name="new_current_position", nullable = false)
    open var newCurrentPosition:CurrentPosition?=null
}