package com.ClinicBackend.demo.ManageFilesAndDB.OrdersWork

import com.ClinicBackend.demo.Entities.Department
import com.ClinicBackend.demo.Entities.ManageOrders.Order
import com.ClinicBackend.demo.Entities.ManagePositions.PositionToBuy
import com.ClinicBackend.demo.Entities.ManageUsers.Role
import com.ClinicBackend.demo.ManageFilesAndDB.FileSystemStorageService
import com.ClinicBackend.demo.ManageFilesAndDB.StorageProperties
import com.ClinicBackend.demo.Repos.OrderRepos
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component
import java.time.LocalDate

@Component
class OrderDAO () {
    @Autowired
    private lateinit var orderRepos: OrderRepos

    fun getOrdersFromDepartment(department: Department)=orderRepos.findByDepartmentEquals(department)

    fun getOrderByName(name:String, department: Department, role:Role): Order?{
        val order = orderRepos.findByLinkToFileEndsWith(name)
        if(order==null)throw RuntimeException("order not found")
        when(role){
            Role.DataProducer->order.readMarkerDP=true
            Role.Editor->order.readMarkerEditor=true
            else -> throw RuntimeException("Unexpected role: $role")
        }
        orderRepos.save(order)
        return order
    }

    fun saveUpdatedOrder(order:Order){
        orderRepos.save(order)
    }

    fun createOrder(linkToOrderFile:String, department: Department){
        orderRepos.save(Order(linkToOrderFile,department))
    }

    fun loadOrderByName(fileName:String){

    }
}