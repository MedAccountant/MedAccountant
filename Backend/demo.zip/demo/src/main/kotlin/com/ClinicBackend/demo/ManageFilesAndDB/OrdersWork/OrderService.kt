package com.ClinicBackend.demo.ManageFilesAndDB.OrdersWork

import com.ClinicBackend.demo.Entities.Department
import com.ClinicBackend.demo.Entities.ManageOrders.Order
import com.ClinicBackend.demo.Entities.ManagePositions.PositionToBuy
import com.ClinicBackend.demo.Entities.ManageUsers.Role
import com.ClinicBackend.demo.ManageFilesAndDB.FileSystemStorageService
import com.ClinicBackend.demo.ManageFilesAndDB.StorageProperties
import com.ClinicBackend.demo.Repos.OrderRepos
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.core.io.UrlResource
import org.springframework.stereotype.Service
import org.springframework.web.multipart.MultipartFile
import java.nio.file.Path
import java.nio.file.Paths
import java.time.LocalDate

@Service
class OrderService() {
    @Autowired
    private lateinit var properties: StorageProperties

    @Autowired
    private lateinit var orderDAO: OrderDAO

    @Autowired
    private lateinit var fileSystemStorageService: FileSystemStorageService

    fun getOrdersFromDepartment(department:Department)=orderDAO.getOrdersFromDepartment(department)
    fun getOrderByName(name:String, department: Department,role: Role):Order?{
        //add department check!!!
        return orderDAO.getOrderByName("$name.xlsx", department,role)
    }

    fun createOrder(positionsToBuy:List<PositionToBuy>){
        val nowDate= LocalDate.now()
        val newFileName="${nowDate.dayOfMonth}.${nowDate.monthValue}.${nowDate.year} Заказ от" +
                " ${positionsToBuy.first().currentPosition!!.department!!.departmentName}.xlsx"
        val linkToOrderFile=fileSystemStorageService.createOrderFile(positionsToBuy,newFileName)
        orderDAO.createOrder(linkToOrderFile,positionsToBuy.first().currentPosition!!.department!!)
    }

    fun setNewDescriptionToOrder(name:String, department: Department,role: Role, newDescription:String):Order{
        val order = orderDAO.getOrderByName("$name.xlsx", department, role)
        order!!.description=newDescription
        orderDAO.saveUpdatedOrder(order)
        return order
    }

    fun setNewOrderFile(file: MultipartFile, name:String, department: Department, role: Role):Order{
        val order = orderDAO.getOrderByName("$name.xlsx", department, role)
        order!!.linkToFile=fileSystemStorageService.updateOrderFile(file)
        orderDAO.saveUpdatedOrder(order)
        return order
    }

    fun loadOrderFileByNameAsResource(fileName:String):UrlResource{
        return fileSystemStorageService.loadAsResource(fileName)
    }
}