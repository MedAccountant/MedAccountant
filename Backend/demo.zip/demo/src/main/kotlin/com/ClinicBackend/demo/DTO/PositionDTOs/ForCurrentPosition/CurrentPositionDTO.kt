package com.ClinicBackend.demo.DTO.PositionDTOs.ForCurrentPosition

import com.ClinicBackend.demo.Entities.ManagePositions.CurrentPosition

class CurrentPositionDTO() {
    var currentPositionId:Long?=null
    var name: String? = null
    var attributeNames:List<String> = mutableListOf<String>()

    constructor(currentPosition: CurrentPosition):this(){
        currentPositionId=currentPosition.currentPositionId
        name=currentPosition.name
        attributeNames=currentPosition.attributes.map { it.attributeName!! }
    }

    override fun toString():String{
        return  "{\n" +
                "\"name\":$name \n" +
                "\"attributes\":[\n" +
                attributeNames.joinToString { ", " }+
                " ]\n}"
    }
}