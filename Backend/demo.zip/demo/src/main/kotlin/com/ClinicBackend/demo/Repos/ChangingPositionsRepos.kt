package com.ClinicBackend.demo.Repos

import com.ClinicBackend.demo.Entities.ManagePositions.ChangingPositions
import com.ClinicBackend.demo.Entities.ManagePositions.CurrentPosition
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface ChangingPositionsRepos: JpaRepository<ChangingPositions, Long> {
    fun findByOldCurrentPosition(oldCurrentPosition: CurrentPosition): ChangingPositions?
    fun findByNewCurrentPosition(newCurrentPosition: CurrentPosition): ChangingPositions?
}