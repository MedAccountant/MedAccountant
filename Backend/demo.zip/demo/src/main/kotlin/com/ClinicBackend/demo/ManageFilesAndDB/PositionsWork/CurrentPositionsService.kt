package com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork

import com.ClinicBackend.demo.DAO.CompanyDAOImpl
import com.ClinicBackend.demo.DTO.DepartmentDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.AttributeDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.ForCurrentPosition.ExtraInfoForCurrentPositionDTO
import com.ClinicBackend.demo.DTO.PositionDTOs.LimitsDTO
import com.ClinicBackend.demo.Entities.ManagePositions.ChangingPositions
import com.ClinicBackend.demo.Entities.Department
import com.ClinicBackend.demo.Entities.ManagePositions.CurrentPosition
import com.ClinicBackend.demo.Entities.ManagePositions.PositionData
import com.ClinicBackend.demo.Entities.ManagePositions.PositionToBuy
import com.ClinicBackend.demo.Repos.ChangingPositionsRepos
import com.ClinicBackend.demo.Repos.CurrentPositionRepos
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.jvm.optionals.getOrNull

@Service
class CurrentPositionsService {

    @Autowired
    private lateinit var companyDAOImpl: CompanyDAOImpl

    @Autowired
    lateinit var currentPositionRepos: CurrentPositionRepos

    @Autowired
    lateinit var positionToBuyService:PositionsToBuyService

    @Autowired
    lateinit var changingPositionsRepos: ChangingPositionsRepos

    fun checkPositionToBuy(currentPosition: CurrentPosition){
        val now = LocalDate.now()
        val currentLimits=currentPosition.limits.first { it.startDate!!<=now && now<=it.endDate!!}
        if(currentPosition.count!!<currentLimits.min!!){
            var positionToBuy=positionToBuyService.findByCurrentPosition(currentPosition)
            if(positionToBuy!=null)positionToBuy.countToBuy=currentLimits.max!!-currentPosition.count!!
            else positionToBuy = PositionToBuy().also {
                it.countToBuy=currentLimits.max!!-currentPosition.count!!
                it.currentPosition=currentPosition
            }
            positionToBuyService.savePositionToBuy(positionToBuy)
        }
    }

    fun getCurrentPositionsFromDepartmentsList(departments: List<Department>):List<CurrentPosition>{
        return departments.flatMap {department->
            department.currentPositions/*.map{
                val inChangingPositions=changingPositionsRepos.findByOldCurrentPosition(it)
                if(inChangingPositions==null)it
                else inChangingPositions.newCurrentPosition!!
            }*/
        }.distinct()
    }

    //global current position management
    fun getCurrentPositionExtraDataGlobal(currentPositionId:Long, departments: List<Department>, companyName: String)
            : ExtraInfoForCurrentPositionDTO {
        val requiredCurrentPosition= currentPositionRepos.findById(currentPositionId).getOrNull()
            ?: throw(PositionManagementException("There is no such current position with id: $currentPositionId"))
        val equalPositions=getEqualCurrentPositions(requiredCurrentPosition,departments)
        var extraInfoForCurrentPositionDTO= ExtraInfoForCurrentPositionDTO()
        val limitDTOs=equalPositions.flatMap {
                position-> position.limits.map { limit->
            LimitsDTO(limit).also { it.department= DepartmentDTO(position.department!!) }
            }
        }.distinct()
        extraInfoForCurrentPositionDTO.limits=limitDTOs
        extraInfoForCurrentPositionDTO.attributes=requiredCurrentPosition.attributes.map { AttributeDTO(it) }
        extraInfoForCurrentPositionDTO.departmentsWherePositionOccurs=equalPositions
            .map { DepartmentDTO(it.department!!) }.distinct()
        return extraInfoForCurrentPositionDTO
    }

    fun saveChangedCurrentPositionsGlobal(currentPositionId: Long,
                                          departments: List<Department>,
                                          newExtraInfoForCurrentPositionDTO: ExtraInfoForCurrentPositionDTO,
                                          companyName: String): ExtraInfoForCurrentPositionDTO {
        val requiredCurrentPosition= currentPositionRepos.findById(currentPositionId).getOrNull()
            ?: throw(PositionManagementException("There is no such current position with id: $currentPositionId"))
        val equalPositions=getEqualCurrentPositions(requiredCurrentPosition,departments)
        for(department in departments){
            val limitsForDepartment=newExtraInfoForCurrentPositionDTO.limits
                .filter { getDepartmentFromCompany(it.department!!.departmentName!!,companyName)==department }
                .map { it.makeLimitsFromDTO() }
            val currentPositionFromDepartment=equalPositions.find { it.department==department }!!
            limitsForDepartment.forEach{it.positionToCurrentPosition=currentPositionFromDepartment}
            currentPositionFromDepartment.limits.clear()
            currentPositionFromDepartment.limits.addAll(limitsForDepartment)
        }
        if(requiredCurrentPosition.attributes !=
            newExtraInfoForCurrentPositionDTO.attributes.map { it.makeAttributeFromDTO() }.toSet()){
            equalPositions.forEach { position->
                position.attributes.clear()
                position.attributes.addAll(newExtraInfoForCurrentPositionDTO.attributes
                    .map { attribute->
                        attribute.makeAttributeFromDTO().also { it.positionToCurrentPosition = position} })
            }
        }
        println("equals: ======================")
        equalPositions.forEach { println(it) }
        saveAllCurrentPositions(equalPositions)
        equalPositions.forEach { deleteCurrentPositionFromChangingPositionsIfExist(it) }
        return getCurrentPositionExtraDataGlobal(currentPositionId,departments,companyName)
    }


    //one department current position management

    fun getCurrentPositionExtraDataOneDep(currentPositionId:Long, department: Department, companyName: String)
            : ExtraInfoForCurrentPositionDTO {
        val requiredCurrentPosition= currentPositionRepos.findById(currentPositionId).getOrNull()
            ?: throw(PositionManagementException("There is no such current position with id: $currentPositionId"))
        val savedChanges=changingPositionsRepos.findByOldCurrentPosition(requiredCurrentPosition)
        var extraInfoForCurrentPositionDTO:ExtraInfoForCurrentPositionDTO
        if(savedChanges!=null){
            extraInfoForCurrentPositionDTO=ExtraInfoForCurrentPositionDTO(savedChanges.newCurrentPosition!!)
            extraInfoForCurrentPositionDTO.changingMarker=true
        }
        else extraInfoForCurrentPositionDTO = ExtraInfoForCurrentPositionDTO(requiredCurrentPosition)
        extraInfoForCurrentPositionDTO.departmentsWherePositionOccurs= listOf(DepartmentDTO(department))
        return extraInfoForCurrentPositionDTO
    }

    fun updateLimitsAndAttributesCurrentPositionOneDep(currentPositionId: Long,
                                                       department: Department,
                                                       newExtraInfoForCurrentPositionDTO: ExtraInfoForCurrentPositionDTO,
                                                       companyName: String): ExtraInfoForCurrentPositionDTO {
        val requiredCurrentPosition= currentPositionRepos.findById(currentPositionId).getOrNull()
            ?: throw(PositionManagementException("There is no such current position with id: $currentPositionId"))
        var savedChanges=changingPositionsRepos.findByOldCurrentPosition(requiredCurrentPosition)
        var newCurrentPosition:CurrentPosition
        if(savedChanges!=null){
            newCurrentPosition=savedChanges.newCurrentPosition!!
            newCurrentPosition.limits.clear()
            newCurrentPosition.attributes.clear()
        }
        else {
            savedChanges = ChangingPositions()
            newCurrentPosition=CurrentPosition()
            savedChanges.newCurrentPosition=newCurrentPosition
            savedChanges.oldCurrentPosition=requiredCurrentPosition
        }
        val limits=newExtraInfoForCurrentPositionDTO.limits
            .filter { getDepartmentFromCompany(it.department!!.departmentName!!,companyName)==department }
            .map { it.makeLimitsFromDTO() }
        limits.forEach{it.positionToCurrentPosition=newCurrentPosition}
        newCurrentPosition.limits.addAll(limits)
        newCurrentPosition.attributes.addAll(newExtraInfoForCurrentPositionDTO.attributes
            .map { attribute->
                attribute.makeAttributeFromDTO().also { it.positionToCurrentPosition = newCurrentPosition} })
        println("equals: ======================")
        println(newCurrentPosition)
        currentPositionRepos.save(newCurrentPosition)//save without checking positions to buy
        changingPositionsRepos.save(savedChanges)
        return getCurrentPositionExtraDataOneDep(currentPositionId,department,companyName)
    }

    fun saveChangedCurrentPositionOneDep(currentPositionId:Long,
                                   department: Department,
                                   companyName: String):Boolean{
        val requiredCurrentPosition= currentPositionRepos.findById(currentPositionId).getOrNull()
            ?: throw(PositionManagementException("There is no such current position with id: $currentPositionId"))
        val savedChanges=changingPositionsRepos.findByOldCurrentPosition(requiredCurrentPosition)
        var newCurrentPosition:CurrentPosition
        if(savedChanges!=null){
            newCurrentPosition=savedChanges.newCurrentPosition!!
            deleteCurrentPositionFromChangingPositionsIfExist(requiredCurrentPosition)
        }
        else {
            throw PositionManagementException("there is no changed version fro position ${requiredCurrentPosition.name}")
        }
        val limits=newCurrentPosition.limits.sortedBy { it.startDate }
        if(limits.isEmpty()) throw SavePositionException("there is no limits")
        var daysCount:Int= ChronoUnit.DAYS.between(limits[0].startDate,limits[0].endDate).toInt()
        for(i in 1 until limits.size){
            if(limits[i-1].endDate!!>=limits[i].startDate!!)
                throw SavePositionException("there are limits with intersections of periods")
            daysCount+= ChronoUnit.DAYS.between(limits[i].startDate,limits[i].endDate).toInt()
        }
        if(daysCount<365)
            throw SavePositionException("there are days without limits for department: ${requiredCurrentPosition.department}")
        requiredCurrentPosition.getLimitsAndAttributes(newCurrentPosition)
        saveCurrentPosition(requiredCurrentPosition)
        return true
    }

    fun saveCurrentPosition(currentPosition: CurrentPosition){
        currentPositionRepos.save(currentPosition)
        checkPositionToBuy(currentPosition)
    }

    fun saveAllCurrentPositions(currentPositions: List<CurrentPosition>){
        currentPositionRepos.saveAll(currentPositions)
        currentPositions.forEach {
            checkPositionToBuy(it)
        }
    }

    fun getEqualCurrentPositions(currentPosition: CurrentPosition, departments: List<Department>):List<CurrentPosition>{
        return currentPositionRepos.findAllByNameAndAttributes_AttributeNameInAndDepartmentIn(currentPosition.name!!,
            currentPosition.attributes.map { it.attributeName!! }.toSet(),
            departments.toSet()).filter {it.attributes==currentPosition.attributes}
    }

    fun getEqualCurrentPositions(positionData: PositionData, departments: List<Department>)=currentPositionRepos
        .findAllByNameAndAttributes_AttributeNameInAndDepartmentIn(
            positionData.name!!,
            positionData.attributes.map{it.attributeName!!}.toSet(),
            departments.toSet()).filter {it.attributes==positionData.attributes}

    fun getDepartmentFromCompany(departmentName:String,companyName: String)=
        companyDAOImpl.getDepartmentByNameAndCompany(departmentName,companyName)

    fun deleteCurrentPositionFromChangingPositionsIfExist(currentPosition: CurrentPosition){
        val changingPositions=changingPositionsRepos.findByOldCurrentPosition(currentPosition)
        if(changingPositions!=null){
            currentPositionRepos.delete(changingPositions.newCurrentPosition!!)
            changingPositionsRepos.delete(changingPositions)
        }
    }
}