package com.ClinicBackend.demo.DTO.PositionDTOs.ForPositionData

import com.ClinicBackend.demo.Entities.ManagePositions.PositionData

class PositionDataDTO() {
    var positionDataId:Long?=null
    var name: String? = null
    var editedMarker:Boolean=false
    var attributeNames:List<String> = mutableListOf<String>()

    constructor(positionData: PositionData):this(){
        positionDataId=positionData.positionDataId
        name=positionData.name
        editedMarker=positionData.editedMarker
        attributeNames=positionData.attributes.map { it.attributeName!! }
    }

    override fun toString():String{
        return  "{\n" +
                "\"name\":$name \n" +
                "\"edited\":$editedMarker \n" +
                "\"attributes\":[\n" +
                attributeNames.joinToString { ", " }+
                " ]\n}"
    }
}