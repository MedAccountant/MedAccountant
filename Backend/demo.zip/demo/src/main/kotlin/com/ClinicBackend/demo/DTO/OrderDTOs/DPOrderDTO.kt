package com.ClinicBackend.demo.DTO.OrderDTOs

import com.ClinicBackend.demo.Entities.ManageOrders.Order

class DPOrderDTO() {
    var orderName: String? = null
    var senderLogin:String?=null
    var readMarker=false
    var complaintAnsMarker=false

    constructor(order: Order):this(){
        orderName=order.linkToFile!!.substringAfterLast("\\").substringBeforeLast(".xlsx")
        senderLogin=order.sender?.login
        readMarker=order.readMarkerDP
        complaintAnsMarker=order.complaintDescription!=null
    }
}