package com.ClinicBackend.demo.Controllers


import com.ClinicBackend.demo.DTO.DepartmentDTO
import com.ClinicBackend.demo.Entities.ManageLoadedData.DocType
import com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork.LoadedDataService
import com.ClinicBackend.demo.ManageFilesAndDB.Exceptions.StorageFileNotFoundException
import com.ClinicBackend.demo.ManageFilesAndDB.StorageService
import io.swagger.v3.oas.annotations.Operation
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import org.springframework.web.multipart.MultipartFile

@RestController
@RequestMapping("/{companyName}/DataProducer")
class DPController{
    @Autowired
    lateinit var utils:Utils

    @Autowired
    lateinit private var storageService: StorageService

    @Autowired
    lateinit private var loadedDataService: LoadedDataService

    //utils
    @Operation(description = "Get list of departments in area of responsibility of Editor")
    @GetMapping("/departments")
    fun getDepartmentsEditor(@PathVariable companyName: String
    ): ResponseEntity<List<DepartmentDTO>> {
        val departmentDTOs=utils.getUsersDepartments(companyName).map { DepartmentDTO(it) }
        return ResponseEntity.ok(departmentDTOs)
    }

    //files management

    @Operation(description = "Upload file to company in area of responsibility of DP")
    @PostMapping("/files")
    fun handleFileUpload(
        @PathVariable companyName:String,
        @RequestParam("doc_type") docType:DocType,
        @RequestParam("file") file: MultipartFile
    ):ResponseEntity<String> {
        loadedDataService.processFile(
            storageService.store(file),
            docType,
            companyName)
        return ResponseEntity.ok(file.name)
    }

    @ExceptionHandler(StorageFileNotFoundException::class)
    fun handleStorageFileNotFound(exc: StorageFileNotFoundException?): ResponseEntity<*> {
        return ResponseEntity.notFound().build<Any>()
    }
}