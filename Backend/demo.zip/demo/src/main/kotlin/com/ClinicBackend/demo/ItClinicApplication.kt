package com.ClinicBackend.demo

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ItClinicApplication

fun main(args: Array<String>) {
	runApplication<ItClinicApplication>(*args)
}
