package com.ClinicBackend.demo.ManageFilesAndDB.PositionsWork

import com.ClinicBackend.demo.Entities.ManagePositions.CurrentPosition
import com.ClinicBackend.demo.Entities.ManagePositions.PositionToBuy
import com.ClinicBackend.demo.ManageFilesAndDB.OrdersWork.OrderService
import com.ClinicBackend.demo.Repos.PositionToBuyRepos
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class PositionsToBuyService {

    @Autowired
    lateinit var positionToBuyRepos: PositionToBuyRepos

    @Autowired
    lateinit var orderService: OrderService

    fun savePositionToBuy(positionToBuy: PositionToBuy){
        positionToBuyRepos.save(positionToBuy)
        val positionsForOrder=positionToBuyRepos.findAllByCurrentPosition_DepartmentEquals(positionToBuy.currentPosition!!.department!!)
        if(positionsForOrder.size>=2L){
            orderService.createOrder(positionsForOrder)
            positionToBuyRepos.deleteAll(positionsForOrder)
        }
    }

    fun findByCurrentPosition(currentPosition:CurrentPosition)=positionToBuyRepos.findByCurrentPosition(currentPosition)
}